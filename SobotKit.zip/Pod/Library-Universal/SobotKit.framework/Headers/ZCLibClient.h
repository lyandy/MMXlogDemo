//
//  ZCLibClient.h
//  SobotKit
//
//  Created by zhangxy on 2016/10/19.
//  Copyright © 2016年 zhichi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ZCLibInitInfo.h"


////////////////////////////////////////////////////////////////
// 自定义回调）
////////////////////////////////////////////////////////////////


/**
 *
 *  消息回调
 *
 */
@protocol ZCReceivedMessageDelegate <NSObject>

//未读消息数获取
-(void)onReceivedMessage:(id) message unRead:(int) nleft obj:(id) object;

@end

/**
 *  未读消息数，block方式获取
 *
 *  @param message 当前消息
 *  @param nleft   未读消息数
 */
typedef void(^ReceivedMessageBlock)(id message,int nleft,NSDictionary *object);






/**
 初始化配置类
 */
@interface ZCLibClient : NSObject

/**
 推送的token
 每次启动应用都需要重新设置
 */
@property (nonatomic,strong) NSData     *token;

/**
 平台标识
 */
@property (nonatomic,strong) NSString     *platformUnionCode;

#pragma mark ---  原 appKey  userId  2.1.0之前的版本使用，之后的版本使用 ZCLibInitInfo中的参数
/**
 appkey，应用的唯一标识
 */
//@property (nonatomic,strong) NSString   *appKey;


/**
 推送的用户Id
 与ZCLibInitInfo.h中的字段统一，取消推送的关键参数
 */
//@property (nonatomic,strong) NSString   *userId;


@property (nonatomic,strong) ZCLibInitInfo *libInitInfo;

/**
 测试模式，
 根据此设置调用的推送证书，默认NO
 NO ,调用生产环境
 YES，测试环境
 */
@property (nonatomic,assign) BOOL isDebugMode;


/**
 自动提醒消息
 说明：如果开启自动提醒消息，当没有在智齿聊天页面的时候，都会主动把消息作为本地通知展示
 */
@property (nonatomic,assign) BOOL autoNotification;


/**
 *  记录当前是否可以显示转人工按钮（记录机器人未知回复的次数已达到，在一次有效的会话中）
 *
 */
@property (nonatomic,assign) BOOL isShowTurnBtn;


////////////////////////////////////////////////////////////////////////


// 同ZCKitInfo中的配置有同等效力，不会覆盖
@property (nonatomic,strong) id<ZCReceivedMessageDelegate> delegate;
// block方式配置
@property (nonatomic,strong) ReceivedMessageBlock          receivedBlock;


+(ZCLibClient *) getZCLibClient;



/**
 初始化智齿客服 2.7.2开始使用
 
 @param appkey 智齿appkey(如果是电商版本，请填写自己公司的APPKEY)
 @param resultBlock 初始化结果回调
 */
-(void)initSobotSDK:(NSString *) appkey result:(void (^)(id object))resultBlock;

/**
 *
 *  初始化智齿客服 (2.7.1之前使用)
 *
 **/
-(void)initSobotSDK:(NSString *) appkey;

/**
 检查初始化状态，（成功/失败）
 @return
 */
-(BOOL) getInitState;


/**
 关闭通道，清理内存，退出智齿客户 移除推送
 说明：调用此方法后将不能接收到离线消息，除非再次进入智齿SDK重新激活,
 isClosePush:YES ,是关闭push；NO离线用户，但是可以收到push推送
 */
+(void) closeAndoutZCServer:(BOOL) isClosePush;


/**
 添加异常统计
 */
+(void)setZCLibUncaughtExceptionHandler;

/**
 获取未读消息数
 
 @return 未读消息数(进入智齿聊天页面会清空)
 */
-(int) getUnReadMessage;



/**
 清空用户下的所有未读消息(本地清空)

 @param userId 接入的用户ID
 */
-(void) clearUnReadNumber:(NSString *) userId;


/**
 获取最后一条消息
 
 @return
 */
-(NSString  *) getLastMessage;


/**
* @deprecated This method is deprecated starting in version 2.6.3
 * @note Please use @code [checkIMConnected]
 初始化智齿客服，会建立长连接通道，监听服务端消息
 检查如果断开就重新连接
 （建议启动应用时调用，没有发起过咨询不会浪费资源,至少转一次人工才有效果）
    isAgInit 是否再次重新构建通道
 */
-(void)initZCIMCaht:(BOOL)isAgInit;


/**
 @note 检查当前消息通道是否建立，没有就重新建立
 如果调用 closeIMConnection 后，可调用此方法重新建立链接
 */
-(void)checkIMConnected;


/**
 @note 关闭当前消息通道，使其不再接受消息
 */
-(void)closeIMConnection;



/**
 移除IM所有监听，可能会影响应用在后台存活时长，如果调用此方法后需要checkIMObserverWithCreate重新激活
 网络监听 ZCNotification_NetworkChange
 UIApplicationDidBecomeActiveNotification
 UIApplicationDidEnterBackgroundNotification
 */
-(void)removeIMAllObserver;


/**
 检查当前监听是否被移除，如果移除就重新注册
 */
-(void)checkIMObserverWithRegister;


@end
